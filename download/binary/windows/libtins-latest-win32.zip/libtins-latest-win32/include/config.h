
/* Define if the compiler supports basic C++11 syntax */
/* #undef HAVE_CXX11 */

/* Have IEEE 802.11 support */
#define HAVE_DOT11

/* Have WPA2 decryption library */
/* #undef HAVE_WPA2_DECRYPTION */
