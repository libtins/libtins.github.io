
/* Define if the compiler supports basic C++11 syntax */
#define HAVE_CXX11

/* Have IEEE 802.11 support */
#define HAVE_DOT11

