#include <tins/tins.h>

using namespace Tins;

size_t count = 0;

bool handle(PDU &pdu) {
    count++;
    return true;
}

int main() {
    FileSniffer sniffer("../input.pcap");
    sniffer.sniff_loop(handle);
    std::cout << count << std::endl;
}

