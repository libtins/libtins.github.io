#!/bin/bash

packet_count=500000
payload_size=742
benchmarks=3
tests_count=2

# add checks plx

echo "[i] Compiling the packet generator."
cd pcap_generator
g++ generator.cpp -o generator -O3 -std=c++0x -ltins

echo "[i] Compiling the libtins benchmark."
cd ../libtins
g++ benchmark.cpp -o benchmark -O3 -std=c++0x -ltins

echo "[i] Compiling the libpcap benchmark."
cd ../libpcap
g++ benchmark.cpp -o benchmark -O3 -std=c++0x -lpcap


echo "[i] Compiling the libcrafter benchmark."
cd ../libcrafter
g++ benchmark.cpp -o benchmark -O3 -std=c++0x -lcrafter

echo "[+] Done compiling."

cd ..
tests=( impacket libcrafter libtins scapy dpkt libpcap )

for test in $(seq 1 $tests_count)
do
    cd pcap_generator
    echo "[i] Generating $packet_count packets, each of size $packet_size"
    ./generator $test $packet_count $payload_size
    cd ..
    echo "[+] Done"
    echo "[i] Executing test case $test"

    for i in ${tests[@]}
    do
        for b in $(seq 1 $benchmarks)
        do
            echo "[i] Executing benchmark number $b for library $i"
            cd $i
            npackets=$(/usr/bin/time -f "%e" -o ../time ./benchmark)
            cd ..
            duration=$(cat time)
            echo "$i $test $npackets $duration" >> results
        done
    done
done
