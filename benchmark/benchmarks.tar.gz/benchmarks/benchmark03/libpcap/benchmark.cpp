#include <pcap.h>
#include <iostream>

size_t count = 0;

void handler(u_char *args, const struct pcap_pkthdr *header, const u_char *packet) {
    count++;
}

int main() {
    char error[PCAP_ERRBUF_SIZE];
    pcap_t *phandle = pcap_open_offline("../input.pcap", error);
    if(!phandle) {
        std::cout << error << std::endl;
    }
    pcap_loop(phandle, 0, handler, 0);
    std::cout << count << std::endl;
}
