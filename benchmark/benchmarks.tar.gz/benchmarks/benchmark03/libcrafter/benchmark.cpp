#include <iostream>
#include <vector>
#include <crafter.h>
#include <pcap.h>

using namespace Crafter;

size_t count = 0;

void handler(u_char *args, const struct pcap_pkthdr *header, const u_char *packet) {
    Packet sniffed_packet;
    sniffed_packet.PacketFromEthernet(packet, header->caplen);
    DNS dns;
    dns.FromRaw(*GetRawLayer(sniffed_packet));
    for(const auto &q : dns.Queries)
        count++;
    for(const auto &a : dns.Answers)    
        count++;
}

int main() {
    char error[PCAP_ERRBUF_SIZE];
    pcap_t *phandle = pcap_open_offline("../input.pcap", error);
    if(!phandle) {
        std::cout << error << std::endl;
    }
    pcap_loop(phandle, 0, handler, 0);
    std::cout << count << std::endl;
}
