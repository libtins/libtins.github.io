#include <tins/tins.h>
#include <cstdlib>
#include <cassert>
#include <iostream>

using namespace Tins;

void dump_to_file(PacketWriter &writer, int packet_count, PDU &packet) {
    while(packet_count--) {
        writer.write(packet);
    }
}

int main(int argc, char *argv[]) {
    int packet_count;
    if(argc != 2) {
        std::cout << "Usage: " << *argv << " <NUM_PACKETS>" << std::endl;
        return 1;
    }
    else {
        packet_count = atoi(argv[1]);
    }
    assert(packet_count > 0);
    
    const uint8_t dns_data[] = {
        98, 243, 129, 128, 0, 1, 0, 1, 0, 0, 0, 0, 6, 103, 111, 111, 
        103, 108, 101, 3, 99, 111, 109, 0, 0, 2, 0, 1, 192, 12, 0, 2, 
        0, 1, 0, 0, 84, 96, 0, 6, 3, 110, 115, 52, 192, 12
    };
    
    PacketWriter writer("../input.pcap", PacketWriter::ETH2);
    EthernetII packet = EthernetII() / IP() / UDP(52, 53) / DNS(dns_data, sizeof(dns_data));
    dump_to_file(writer, packet_count, packet);
}

