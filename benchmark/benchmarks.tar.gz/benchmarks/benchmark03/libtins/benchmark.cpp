#include <tins/tins.h>

using namespace Tins;

size_t count = 0;

bool handle(const PDU &pdu) {
    DNS dns = pdu.rfind_pdu<RawPDU>().to<DNS>();
    for(const auto &query : dns.queries())
        count++;
    for(const auto &answer : dns.answers())
        count++;
    return true;
}

int main() {
    FileSniffer sniffer("../input.pcap");
    sniffer.sniff_loop(handle);
    std::cout << count << std::endl;
}

